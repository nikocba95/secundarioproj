package GUI;

import java.time.LocalDate;


import Model.Interface.ExamenInterface;
import Model.Interface.MateriaInterface;
import javafx.scene.chart.BarChart;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class AlumnoVerCalificaciones {
	
	
	public Label lblNombreAlumno;
	public TableView<ExamenInterface> tablaHistorial;
	public TableColumn<ExamenInterface, String> colmunaMateriaH;
	public TableColumn<ExamenInterface, Integer> columnaNotaH;
	public TableColumn<ExamenInterface, LocalDate> columnaFechaH;
	public TableColumn<ExamenInterface, String> columnaTipoExamenH;
	public ComboBox<MateriaInterface> comboMateria;
	public TableView<MateriaInterface> tablaMaterias;
	public TableColumn<MateriaInterface, String> columnaMateriaM;
	public TableColumn<MateriaInterface, Integer> columnaNotaM;
	public TableColumn<MateriaInterface, LocalDate> columnaFechaM;
	public TableColumn<MateriaInterface, String> columnaTipoExamenM;
	public TableView<ExamenInterface> tablaAtencion;
	public TableColumn<ExamenInterface, String> columnaMateriaA;
	public TableColumn<ExamenInterface, Float> columnaPromedioA;
	public Button buttonVolver;
	
	


}
