package BO;

public class MateriasBO {

}
