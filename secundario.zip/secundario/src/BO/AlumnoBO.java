package BO;



import Model.Interface.AlumnoInterface;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class AlumnoBO {

	public static ObservableList<AlumnoInterface> getTodosAlumnos(ObservableList<AlumnoInterface> alumnos){
		
		ObservableList<AlumnoInterface> asc = FXCollections.observableArrayList();
		
		for(AlumnoInterface a : alumnos)
			asc.add(a);
		
		return asc;
	}
	
	
	
	
}
