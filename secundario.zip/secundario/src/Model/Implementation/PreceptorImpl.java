package Model.Implementation;

import Model.Abstract.PreceptorAbstract;

public class PreceptorImpl extends PreceptorAbstract{

}
