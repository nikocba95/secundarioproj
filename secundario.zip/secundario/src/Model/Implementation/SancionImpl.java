package Model.Implementation;

import Model.Abstract.SancionAbstract;

public class SancionImpl extends SancionAbstract{

}
