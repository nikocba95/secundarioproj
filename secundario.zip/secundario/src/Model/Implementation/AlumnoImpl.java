package Model.Implementation;

import Model.Abstract.AlumnoAbstract;

public class AlumnoImpl extends AlumnoAbstract{

}
