package Model.Implementation;

import Model.Abstract.EspecialidadAbstract;

public class EspecialidadImpl extends EspecialidadAbstract {

}
