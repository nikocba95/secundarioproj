package Model.Implementation;

import Model.Abstract.PersonaAbstract;

public class PersonaImpl extends PersonaAbstract{

}
