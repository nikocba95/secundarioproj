package Model.Implementation;

import Model.Abstract.DocenteAbstract;

public class DocenteImpl extends DocenteAbstract{

}
