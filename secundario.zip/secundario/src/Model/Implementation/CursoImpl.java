package Model.Implementation;

import Model.Abstract.CursoAbstract;

public class CursoImpl extends CursoAbstract{

}
