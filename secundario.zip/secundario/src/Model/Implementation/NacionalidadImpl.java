package Model.Implementation;

import Model.Abstract.NacionalidadAbstract;

public class NacionalidadImpl extends NacionalidadAbstract{

}
