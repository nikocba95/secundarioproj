package Model.Implementation;

import Model.Abstract.DomicilioAbstract;

public class DomicilioImpl extends DomicilioAbstract{

}
