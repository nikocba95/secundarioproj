package Model.Implementation;

import Model.Abstract.UsuariosAbstract;

public class UsusariosImpl extends UsuariosAbstract{

}
