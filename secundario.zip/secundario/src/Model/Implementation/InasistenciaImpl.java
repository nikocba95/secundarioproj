package Model.Implementation;

import Model.Abstract.InasistenciaAbstract;

public class InasistenciaImpl extends InasistenciaAbstract{

}
