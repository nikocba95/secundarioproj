package Model.Implementation;

import Model.Abstract.MateriaAbstract;

public class MateriaImpl extends MateriaAbstract{

}
