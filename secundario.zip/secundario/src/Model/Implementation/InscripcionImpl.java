package Model.Implementation;

import Model.Abstract.InscripcionAbstract;

public class InscripcionImpl extends InscripcionAbstract{

}
