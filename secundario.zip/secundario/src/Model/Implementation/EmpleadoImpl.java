package Model.Implementation;

import Model.Abstract.EmpleadoAbstract;

public class EmpleadoImpl extends EmpleadoAbstract{

}
