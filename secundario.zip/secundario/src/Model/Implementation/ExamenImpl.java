package Model.Implementation;

import Model.Abstract.ExamenAbstract;

public class ExamenImpl extends ExamenAbstract{

}
