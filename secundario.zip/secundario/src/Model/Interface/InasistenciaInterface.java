package Model.Interface;

import java.time.LocalDate;

public interface InasistenciaInterface {

	Integer getIdInasistencia();

	void setIdInasistencia(Integer idInasistencia);

	LocalDate getFecha();

	void setFecha(LocalDate fecha);

	Boolean getJustificada();

	void setJustificada(Boolean justificada);

	Integer getTrimestre1();

	void setTrimestre1(Integer trimestre1);

	Integer getTrimestre2();

	void setTrimestre2(Integer trimestre2);

	Integer getTrimestre3();

	void setTrimestre3(Integer trimestre3);

	Integer getTotal();

	void setTotal(Integer total);

	Integer getLlegadasTarde();

	void setLlegadasTarde(Integer llegadasTarde);

}