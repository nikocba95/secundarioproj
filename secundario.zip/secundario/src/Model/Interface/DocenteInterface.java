package Model.Interface;

public interface DocenteInterface extends EmpleadoInterface{

	String getTitulo();

	void setTitulo(String titulo);

}