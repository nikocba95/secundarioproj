package Model.Interface;

import java.time.LocalDate;

public interface InscripcionInterface {

	Integer getCicloLectivo();

	void setCicloLectivo(Integer cicloLectivo);

	LocalDate getFechaInscripcion();

	void setFechaInscripcion(LocalDate fechaInscripcion);

	Boolean getIngresoDirecto();

	void setIngresoDirecto(Boolean ingresoDirecto);

	Boolean getIngresoConPase();

	void setIngresoConPase(Boolean ingresoConPase);

	Integer getCodCurso();

	void setCodCurso(Integer codCurso);

	Integer getDni();

	void setDni(Integer dni);

}