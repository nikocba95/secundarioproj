package Model.Interface;

import java.time.LocalDate;

public interface AlumnoInterface extends PersonaInterface{

	Integer getMatricula();

	void setMatricula(Integer matricula);

	String getEstablecimientoAnterior();

	void setEstablecimientoAnterior(String establecimientoAnterior);

	Boolean getEstado();

	void setEstado(Boolean estado);

	String getConstanciaSexto();

	void setConstanciaSexto(String constanciaSexto);

	LocalDate getFechaEmision();

	void setFechaEmision(LocalDate fechaEmision);

	String getNombrePadre();

	void setNombrePadre(String nombrePadre);

	String getApellidoPadre();

	void setApellidoPadre(String apellidoPadre);

	String getNombreMadre();

	void setNombreMadre(String nombreMadre);

	String getApellidoMadre();

	void setApellidoMadre(String apellidoMadre);

	String getObservacion();

	void setObservacion(String observacion);

}