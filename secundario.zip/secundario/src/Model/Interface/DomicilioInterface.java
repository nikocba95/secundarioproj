package Model.Interface;

public interface DomicilioInterface {

	Integer getCodDomicilio();

	void setCodDomicilio(Integer codDomicilio);

	String getBarrio();

	void setBarrio(String barrio);

	String getCalle();

	void setCalle(String calle);

	Integer getNumero();

	void setNumero(Integer numero);

	Integer getPiso();

	void setPiso(Integer piso);

	String getDpto();

	void setDpto(String dpto);

}