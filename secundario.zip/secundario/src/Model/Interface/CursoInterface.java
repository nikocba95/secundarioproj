package Model.Interface;

public interface CursoInterface {

	Integer getCodCurso();

	void setCodCurso(Integer codCurso);

	Integer getAnio();

	void setAnio(Integer anio);

	String getDivision();

	void setDivision(String division);

}