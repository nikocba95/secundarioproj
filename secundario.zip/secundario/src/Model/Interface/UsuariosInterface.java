package Model.Interface;

public interface UsuariosInterface {

	String getUser();

	void setUser(String user);

	String getPassword();

	void setPassword(String password);

	String getTipoUser();

	void setTipoUser(String tipoUser);

}