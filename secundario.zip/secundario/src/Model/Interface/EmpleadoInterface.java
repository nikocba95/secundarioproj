package Model.Interface;

public interface EmpleadoInterface extends PersonaInterface{

	Integer getLegajo();

	void setLegajo(Integer legajo);

	Boolean getEstado();

	void setEstado(Boolean estado);

}