package Model.Interface;

public interface EspecialidadInterface {

	Integer getCodEspecialidad();

	void setCodEspecialidad(Integer codEspecialidad);

	String getEspecialidad();

	void setEspecialidad(String especialidad);

}