package Model.Interface;

public interface MateriaInterface {

	Integer getCodMateria();

	void setCodMateria(Integer codMateria);

	String getMateria();

	void setMateria(String materia);

	Boolean getMateriaOptativa();

	void setMateriaOptativa(Boolean materiaOptativa);

}