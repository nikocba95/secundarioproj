package Model.Interface;

public interface PreceptorInterface extends EmpleadoInterface{

	String getTurno();

	void setTurno(String turno);

}