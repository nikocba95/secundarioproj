package Model.Interface;

public interface NacionalidadInterface {

	Integer getCodPais();

	void setCodPais(Integer codPais);

	String getPais();

	void setPais(String pais);

	String getNacionalidad();

	void setNacionalidad(String nacionalidad);

	Integer getCodProvincia();

	void setCodProvincia(Integer codProvincia);

	String getProvincia();

	void setProvincia(String provincia);

	Integer getCodLocalidad();

	void setCodLocalidad(Integer codLocalidad);

	String getLocalidad();

	void setLocalidad(String localidad);

}