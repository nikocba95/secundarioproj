package Model.Interface;

import java.time.LocalDate;

public interface SancionInterface {

	String getIdSanciones();

	void setIdSanciones(String idSanciones);

	LocalDate getFecha();

	void setFecha(LocalDate fecha);

	String getObservacion();

	void setObservacion(String observacion);

	Integer getNroSanciones();

	void setNroSanciones(Integer nroSanciones);

	Integer getTotal();

	void setTotal(Integer total);

	Integer getCodSancion();

	void setCodSancion(Integer codSancion);

	String getSancion();

	void setSancion(String sancion);

}