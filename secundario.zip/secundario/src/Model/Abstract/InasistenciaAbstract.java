package Model.Abstract;

import java.time.LocalDate;

import Model.Interface.InasistenciaInterface;

public abstract class InasistenciaAbstract implements InasistenciaInterface {
	
	private Integer idInasistencia;
	private LocalDate fecha;
	private Boolean Justificada;
	private Integer trimestre1;
	private Integer trimestre2;
	private Integer trimestre3;
	private Integer total;
	private Integer llegadasTarde;

	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#getIdInasistencia()
	 */
	@Override
	public Integer getIdInasistencia() {
		return idInasistencia;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#setIdInasistencia(java.lang.Integer)
	 */
	@Override
	public void setIdInasistencia(Integer idInasistencia) {
		this.idInasistencia = idInasistencia;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#getFecha()
	 */
	@Override
	public LocalDate getFecha() {
		return fecha;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#setFecha(java.time.LocalDate)
	 */
	@Override
	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#getJustificada()
	 */
	@Override
	public Boolean getJustificada() {
		return Justificada;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#setJustificada(java.lang.Boolean)
	 */
	@Override
	public void setJustificada(Boolean justificada) {
		Justificada = justificada;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#getTrimestre1()
	 */
	@Override
	public Integer getTrimestre1() {
		return trimestre1;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#setTrimestre1(java.lang.Integer)
	 */
	@Override
	public void setTrimestre1(Integer trimestre1) {
		this.trimestre1 = trimestre1;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#getTrimestre2()
	 */
	@Override
	public Integer getTrimestre2() {
		return trimestre2;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#setTrimestre2(java.lang.Integer)
	 */
	@Override
	public void setTrimestre2(Integer trimestre2) {
		this.trimestre2 = trimestre2;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#getTrimestre3()
	 */
	@Override
	public Integer getTrimestre3() {
		return trimestre3;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#setTrimestre3(java.lang.Integer)
	 */
	@Override
	public void setTrimestre3(Integer trimestre3) {
		this.trimestre3 = trimestre3;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#getTotal()
	 */
	@Override
	public Integer getTotal() {
		return total;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#setTotal(java.lang.Integer)
	 */
	@Override
	public void setTotal(Integer total) {
		this.total = total;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#getLlegadasTarde()
	 */
	@Override
	public Integer getLlegadasTarde() {
		return llegadasTarde;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InasistenciaInterface#setLlegadasTarde(java.lang.Integer)
	 */
	@Override
	public void setLlegadasTarde(Integer llegadasTarde) {
		this.llegadasTarde = llegadasTarde;
	}
	
	
	

}
