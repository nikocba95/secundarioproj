package Model.Abstract;

import java.time.LocalDate;

import Model.Interface.ExamenInterface;

public abstract class ExamenAbstract implements ExamenInterface {
	
	private Integer mesa;
	private LocalDate fecha;
	private String obs;
	private Integer codExamen;
	private String examen;
	private Integer nota;

	/* (non-Javadoc)
	 * @see Model.Abstract.ExamenInterface#getMesa()
	 */
	@Override
	public Integer getMesa() {
		return mesa;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.ExamenInterface#setMesa(java.lang.Integer)
	 */
	@Override
	public void setMesa(Integer mesa) {
		this.mesa = mesa;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.ExamenInterface#getFecha()
	 */
	@Override
	public LocalDate getFecha() {
		return fecha;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.ExamenInterface#setFecha(java.time.LocalDate)
	 */
	@Override
	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.ExamenInterface#getObs()
	 */
	@Override
	public String getObs() {
		return obs;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.ExamenInterface#setObs(java.lang.String)
	 */
	@Override
	public void setObs(String obs) {
		this.obs = obs;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.ExamenInterface#getCodExamen()
	 */
	@Override
	public Integer getCodExamen() {
		return codExamen;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.ExamenInterface#setCodExamen(java.lang.Integer)
	 */
	@Override
	public void setCodExamen(Integer codExamen) {
		this.codExamen = codExamen;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.ExamenInterface#getExamen()
	 */
	@Override
	public String getExamen() {
		return examen;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.ExamenInterface#setExamen(java.lang.String)
	 */
	@Override
	public void setExamen(String examen) {
		this.examen = examen;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.ExamenInterface#getNota()
	 */
	@Override
	public Integer getNota() {
		return nota;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.ExamenInterface#setNota(java.lang.Integer)
	 */
	@Override
	public void setNota(Integer nota) {
		this.nota = nota;
	}
	
	
	

}
