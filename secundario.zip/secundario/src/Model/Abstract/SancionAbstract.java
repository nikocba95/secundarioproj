package Model.Abstract;

import java.time.LocalDate;

import Model.Interface.SancionInterface;

public abstract class SancionAbstract implements SancionInterface {

	private String idSanciones;
	private LocalDate fecha;
	private String observacion;
	private Integer nroSanciones;
	private Integer total;
	private Integer codSancion;
	private String sancion;
	
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#getIdSanciones()
	 */
	@Override
	public String getIdSanciones() {
		return idSanciones;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#setIdSanciones(java.lang.String)
	 */
	@Override
	public void setIdSanciones(String idSanciones) {
		this.idSanciones = idSanciones;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#getFecha()
	 */
	@Override
	public LocalDate getFecha() {
		return fecha;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#setFecha(java.time.LocalDate)
	 */
	@Override
	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#getObservacion()
	 */
	@Override
	public String getObservacion() {
		return observacion;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#setObservacion(java.lang.String)
	 */
	@Override
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#getNroSanciones()
	 */
	@Override
	public Integer getNroSanciones() {
		return nroSanciones;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#setNroSanciones(java.lang.Integer)
	 */
	@Override
	public void setNroSanciones(Integer nroSanciones) {
		this.nroSanciones = nroSanciones;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#getTotal()
	 */
	@Override
	public Integer getTotal() {
		return total;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#setTotal(java.lang.Integer)
	 */
	@Override
	public void setTotal(Integer total) {
		this.total = total;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#getCodSancion()
	 */
	@Override
	public Integer getCodSancion() {
		return codSancion;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#setCodSancion(java.lang.Integer)
	 */
	@Override
	public void setCodSancion(Integer codSancion) {
		this.codSancion = codSancion;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#getSancion()
	 */
	@Override
	public String getSancion() {
		return sancion;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.SancionInterface#setSancion(java.lang.String)
	 */
	@Override
	public void setSancion(String sancion) {
		this.sancion = sancion;
	}
	
	
}
