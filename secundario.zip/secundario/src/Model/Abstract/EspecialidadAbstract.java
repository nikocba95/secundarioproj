package Model.Abstract;

import Model.Interface.EspecialidadInterface;

public abstract class EspecialidadAbstract implements EspecialidadInterface {

	
	private Integer codEspecialidad;
	private String especialidad;

	/* (non-Javadoc)
	 * @see Model.Abstract.EspecialidadInterface#getCodEspecialidad()
	 */
	@Override
	public Integer getCodEspecialidad() {
		return codEspecialidad;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.EspecialidadInterface#setCodEspecialidad(java.lang.Integer)
	 */
	@Override
	public void setCodEspecialidad(Integer codEspecialidad) {
		this.codEspecialidad = codEspecialidad;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.EspecialidadInterface#getEspecialidad()
	 */
	@Override
	public String getEspecialidad() {
		return especialidad;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.EspecialidadInterface#setEspecialidad(java.lang.String)
	 */
	@Override
	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}
	
	
}
