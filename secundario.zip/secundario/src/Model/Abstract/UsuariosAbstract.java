package Model.Abstract;

import Model.Interface.UsuariosInterface;

public abstract class UsuariosAbstract implements UsuariosInterface {

	private String user;
	private String password;
	private String tipoUser;
	
	/* (non-Javadoc)
	 * @see Model.Abstract.UsuariosInterface#getUser()
	 */
	@Override
	public String getUser() {
		return user;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.UsuariosInterface#setUser(java.lang.String)
	 */
	@Override
	public void setUser(String user) {
		this.user = user;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.UsuariosInterface#getPassword()
	 */
	@Override
	public String getPassword() {
		return password;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.UsuariosInterface#setPassword(java.lang.String)
	 */
	@Override
	public void setPassword(String password) {
		this.password = password;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.UsuariosInterface#getTipoUser()
	 */
	@Override
	public String getTipoUser() {
		return tipoUser;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.UsuariosInterface#setTipoUser(java.lang.String)
	 */
	@Override
	public void setTipoUser(String tipoUser) {
		this.tipoUser = tipoUser;
	}
	
	
	
}
