package Model.Abstract;

import Model.Interface.DomicilioInterface;

public abstract class DomicilioAbstract implements DomicilioInterface {

	private Integer codDomicilio;
	private String barrio;
	private String calle;
	private Integer numero;
	private Integer piso;
	private String dpto;
	
	/* (non-Javadoc)
	 * @see Model.Abstract.DomicilioInterface#getCodDomicilio()
	 */
	@Override
	public Integer getCodDomicilio() {
		return codDomicilio;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.DomicilioInterface#setCodDomicilio(java.lang.Integer)
	 */
	@Override
	public void setCodDomicilio(Integer codDomicilio) {
		this.codDomicilio = codDomicilio;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.DomicilioInterface#getBarrio()
	 */
	@Override
	public String getBarrio() {
		return barrio;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.DomicilioInterface#setBarrio(java.lang.String)
	 */
	@Override
	public void setBarrio(String barrio) {
		this.barrio = barrio;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.DomicilioInterface#getCalle()
	 */
	@Override
	public String getCalle() {
		return calle;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.DomicilioInterface#setCalle(java.lang.String)
	 */
	@Override
	public void setCalle(String calle) {
		this.calle = calle;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.DomicilioInterface#getNumero()
	 */
	@Override
	public Integer getNumero() {
		return numero;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.DomicilioInterface#setNumero(java.lang.Integer)
	 */
	@Override
	public void setNumero(Integer numero) {
		this.numero = numero;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.DomicilioInterface#getPiso()
	 */
	@Override
	public Integer getPiso() {
		return piso;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.DomicilioInterface#setPiso(java.lang.Integer)
	 */
	@Override
	public void setPiso(Integer piso) {
		this.piso = piso;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.DomicilioInterface#getDpto()
	 */
	@Override
	public String getDpto() {
		return dpto;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.DomicilioInterface#setDpto(java.lang.String)
	 */
	@Override
	public void setDpto(String dpto) {
		this.dpto = dpto;
	}
	
	
	
}
