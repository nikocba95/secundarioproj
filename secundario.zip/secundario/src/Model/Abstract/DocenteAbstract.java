package Model.Abstract;

import Model.Interface.DocenteInterface;

public abstract class DocenteAbstract extends EmpleadoAbstract implements DocenteInterface {

	private String titulo;

	/* (non-Javadoc)
	 * @see Model.Abstract.DocenteInterface#getTitulo()
	 */
	@Override
	public String getTitulo() {
		return titulo;
	}

	/* (non-Javadoc)
	 * @see Model.Abstract.DocenteInterface#setTitulo(java.lang.String)
	 */
	@Override
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	
}
