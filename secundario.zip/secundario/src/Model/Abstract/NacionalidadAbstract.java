package Model.Abstract;

import Model.Interface.NacionalidadInterface;

public abstract class NacionalidadAbstract implements NacionalidadInterface {
	
	private Integer codPais;
	private String pais;
	private String nacionalidad;
	private Integer codProvincia;
	private String provincia;
	private Integer codLocalidad;
	private String localidad;
	
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#getCodPais()
	 */
	@Override
	public Integer getCodPais() {
		return codPais;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#setCodPais(java.lang.Integer)
	 */
	@Override
	public void setCodPais(Integer codPais) {
		this.codPais = codPais;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#getPais()
	 */
	@Override
	public String getPais() {
		return pais;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#setPais(java.lang.String)
	 */
	@Override
	public void setPais(String pais) {
		this.pais = pais;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#getNacionalidad()
	 */
	@Override
	public String getNacionalidad() {
		return nacionalidad;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#setNacionalidad(java.lang.String)
	 */
	@Override
	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#getCodProvincia()
	 */
	@Override
	public Integer getCodProvincia() {
		return codProvincia;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#setCodProvincia(java.lang.Integer)
	 */
	@Override
	public void setCodProvincia(Integer codProvincia) {
		this.codProvincia = codProvincia;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#getProvincia()
	 */
	@Override
	public String getProvincia() {
		return provincia;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#setProvincia(java.lang.String)
	 */
	@Override
	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#getCodLocalidad()
	 */
	@Override
	public Integer getCodLocalidad() {
		return codLocalidad;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#setCodLocalidad(java.lang.Integer)
	 */
	@Override
	public void setCodLocalidad(Integer codLocalidad) {
		this.codLocalidad = codLocalidad;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#getLocalidad()
	 */
	@Override
	public String getLocalidad() {
		return localidad;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.NacionalidadInterface#setLocalidad(java.lang.String)
	 */
	@Override
	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}
	
	

}
