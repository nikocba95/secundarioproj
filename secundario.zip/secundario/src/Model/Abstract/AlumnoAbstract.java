package Model.Abstract;

import java.time.LocalDate;

import Model.Interface.AlumnoInterface;

public abstract class AlumnoAbstract extends PersonaAbstract implements AlumnoInterface {
	
	private Integer matricula;
	private String establecimientoAnterior;
	private Boolean estado;
	private String constanciaSexto;
	private LocalDate fechaEmision;
	private String nombrePadre;
	private String apellidoPadre;
	private String nombreMadre;
	private String apellidoMadre;
	private String observacion;
	
	
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#getMatricula()
	 */
	@Override
	public Integer getMatricula() {
		return matricula;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#setMatricula(java.lang.Integer)
	 */
	@Override
	public void setMatricula(Integer matricula) {
		this.matricula = matricula;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#getEstablecimientoAnterior()
	 */
	@Override
	public String getEstablecimientoAnterior() {
		return establecimientoAnterior;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#setEstablecimientoAnterior(java.lang.String)
	 */
	@Override
	public void setEstablecimientoAnterior(String establecimientoAnterior) {
		this.establecimientoAnterior = establecimientoAnterior;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#getEstado()
	 */
	@Override
	public Boolean getEstado() {
		return estado;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#setEstado(java.lang.Boolean)
	 */
	@Override
	public void setEstado(Boolean estado) {
		this.estado = estado;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#getConstanciaSexto()
	 */
	@Override
	public String getConstanciaSexto() {
		return constanciaSexto;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#setConstanciaSexto(java.lang.String)
	 */
	@Override
	public void setConstanciaSexto(String constanciaSexto) {
		this.constanciaSexto = constanciaSexto;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#getFechaEmision()
	 */
	@Override
	public LocalDate getFechaEmision() {
		return fechaEmision;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#setFechaEmision(java.time.LocalDate)
	 */
	@Override
	public void setFechaEmision(LocalDate fechaEmision) {
		this.fechaEmision = fechaEmision;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#getNombrePadre()
	 */
	@Override
	public String getNombrePadre() {
		return nombrePadre;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#setNombrePadre(java.lang.String)
	 */
	@Override
	public void setNombrePadre(String nombrePadre) {
		this.nombrePadre = nombrePadre;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#getApellidoPadre()
	 */
	@Override
	public String getApellidoPadre() {
		return apellidoPadre;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#setApellidoPadre(java.lang.String)
	 */
	@Override
	public void setApellidoPadre(String apellidoPadre) {
		this.apellidoPadre = apellidoPadre;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#getNombreMadre()
	 */
	@Override
	public String getNombreMadre() {
		return nombreMadre;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#setNombreMadre(java.lang.String)
	 */
	@Override
	public void setNombreMadre(String nombreMadre) {
		this.nombreMadre = nombreMadre;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#getApellidoMadre()
	 */
	@Override
	public String getApellidoMadre() {
		return apellidoMadre;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#setApellidoMadre(java.lang.String)
	 */
	@Override
	public void setApellidoMadre(String apellidoMadre) {
		this.apellidoMadre = apellidoMadre;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#getObservacion()
	 */
	@Override
	public String getObservacion() {
		return observacion;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.AlumnoInterface#setObservacion(java.lang.String)
	 */
	@Override
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	
	
	
	

}
