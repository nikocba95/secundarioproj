package Model.Abstract;

import Model.Interface.PreceptorInterface;

public abstract class PreceptorAbstract extends EmpleadoAbstract implements PreceptorInterface {

	private String turno;

	/* (non-Javadoc)
	 * @see Model.Abstract.PreceptorInterface#getTurno()
	 */
	@Override
	public String getTurno() {
		return turno;
	}

	/* (non-Javadoc)
	 * @see Model.Abstract.PreceptorInterface#setTurno(java.lang.String)
	 */
	@Override
	public void setTurno(String turno) {
		this.turno = turno;
	}
	
	
}
