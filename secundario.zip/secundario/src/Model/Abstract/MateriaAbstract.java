package Model.Abstract;

import Model.Interface.MateriaInterface;

public abstract class MateriaAbstract implements MateriaInterface {

	private Integer codMateria;
	private String materia;
	private Boolean materiaOptativa ;
	
	/* (non-Javadoc)
	 * @see Model.Abstract.MateriaInterface#getCodMateria()
	 */
	@Override
	public Integer getCodMateria() {
		return codMateria;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.MateriaInterface#setCodMateria(java.lang.Integer)
	 */
	@Override
	public void setCodMateria(Integer codMateria) {
		this.codMateria = codMateria;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.MateriaInterface#getMateria()
	 */
	@Override
	public String getMateria() {
		return materia;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.MateriaInterface#setMateria(java.lang.String)
	 */
	@Override
	public void setMateria(String materia) {
		this.materia = materia;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.MateriaInterface#getMateriaOptativa()
	 */
	@Override
	public Boolean getMateriaOptativa() {
		return materiaOptativa;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.MateriaInterface#setMateriaOptativa(java.lang.Boolean)
	 */
	@Override
	public void setMateriaOptativa(Boolean materiaOptativa) {
		this.materiaOptativa = materiaOptativa;
	}
	
	
}
