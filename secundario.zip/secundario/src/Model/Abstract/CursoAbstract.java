package Model.Abstract;

import Model.Interface.CursoInterface;

public abstract class CursoAbstract implements CursoInterface {
	
	private Integer codCurso;
	private Integer anio;
	private String division;
	
	/* (non-Javadoc)
	 * @see Model.Abstract.CursoInterface#getCodCurso()
	 */
	@Override
	public Integer getCodCurso() {
		return codCurso;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.CursoInterface#setCodCurso(java.lang.Integer)
	 */
	@Override
	public void setCodCurso(Integer codCurso) {
		this.codCurso = codCurso;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.CursoInterface#getAnio()
	 */
	@Override
	public Integer getAnio() {
		return anio;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.CursoInterface#setAnio(java.lang.Integer)
	 */
	@Override
	public void setAnio(Integer anio) {
		this.anio = anio;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.CursoInterface#getDivision()
	 */
	@Override
	public String getDivision() {
		return division;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.CursoInterface#setDivision(java.lang.String)
	 */
	@Override
	public void setDivision(String division) {
		this.division = division;
	}
	
	

}
