package Model.Abstract;

import java.time.LocalDate;

import Model.Interface.InscripcionInterface;

public abstract class InscripcionAbstract implements InscripcionInterface {

	private Integer cicloLectivo;
	private LocalDate fechaInscripcion;
	private Boolean ingresoDirecto;
	private Boolean ingresoConPase;
	private Integer codCurso;
	private Integer dni;
	
	/* (non-Javadoc)
	 * @see Model.Abstract.InscripcionInterface#getCicloLectivo()
	 */
	@Override
	public Integer getCicloLectivo() {
		return cicloLectivo;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InscripcionInterface#setCicloLectivo(java.lang.Integer)
	 */
	@Override
	public void setCicloLectivo(Integer cicloLectivo) {
		this.cicloLectivo = cicloLectivo;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InscripcionInterface#getFechaInscripcion()
	 */
	@Override
	public LocalDate getFechaInscripcion() {
		return fechaInscripcion;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InscripcionInterface#setFechaInscripcion(java.time.LocalDate)
	 */
	@Override
	public void setFechaInscripcion(LocalDate fechaInscripcion) {
		this.fechaInscripcion = fechaInscripcion;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InscripcionInterface#getIngresoDirecto()
	 */
	@Override
	public Boolean getIngresoDirecto() {
		return ingresoDirecto;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InscripcionInterface#setIngresoDirecto(java.lang.Boolean)
	 */
	@Override
	public void setIngresoDirecto(Boolean ingresoDirecto) {
		this.ingresoDirecto = ingresoDirecto;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InscripcionInterface#getIngresoConPase()
	 */
	@Override
	public Boolean getIngresoConPase() {
		return ingresoConPase;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InscripcionInterface#setIngresoConPase(java.lang.Boolean)
	 */
	@Override
	public void setIngresoConPase(Boolean ingresoConPase) {
		this.ingresoConPase = ingresoConPase;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InscripcionInterface#getCodCurso()
	 */
	@Override
	public Integer getCodCurso() {
		return codCurso;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InscripcionInterface#setCodCurso(java.lang.Integer)
	 */
	@Override
	public void setCodCurso(Integer codCurso) {
		this.codCurso = codCurso;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InscripcionInterface#getDni()
	 */
	@Override
	public Integer getDni() {
		return dni;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.InscripcionInterface#setDni(java.lang.Integer)
	 */
	@Override
	public void setDni(Integer dni) {
		this.dni = dni;
	}
	
	
}
