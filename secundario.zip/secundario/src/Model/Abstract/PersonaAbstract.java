package Model.Abstract;

import java.io.FileInputStream;
import java.time.LocalDate;

import Model.Interface.PersonaInterface;

public abstract class PersonaAbstract implements PersonaInterface {

	
	private Integer dni;
	private Integer cuil;
	private String nombre;
	private String apellido;
	private String sexo;
	private LocalDate fechaNacimiento;
	private Integer telefono;
	private String correo;
	private FileInputStream foto;
	
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#getDni()
	 */
	@Override
	public Integer getDni() {
		return dni;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#setDni(java.lang.Integer)
	 */
	@Override
	public void setDni(Integer dni) {
		this.dni = dni;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#getCuil()
	 */
	@Override
	public Integer getCuil() {
		return cuil;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#setCuil(java.lang.Integer)
	 */
	@Override
	public void setCuil(Integer cuil) {
		this.cuil = cuil;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#getNombre()
	 */
	@Override
	public String getNombre() {
		return nombre;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#setNombre(java.lang.String)
	 */
	@Override
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#getApellido()
	 */
	@Override
	public String getApellido() {
		return apellido;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#setApellido(java.lang.String)
	 */
	@Override
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#getSexo()
	 */
	@Override
	public String getSexo() {
		return sexo;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#setSexo(java.lang.String)
	 */
	@Override
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#getFechaNacimiento()
	 */
	@Override
	public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#setFechaNacimiento(java.time.LocalDate)
	 */
	@Override
	public void setFechaNacimiento(LocalDate fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#getTelefono()
	 */
	@Override
	public Integer getTelefono() {
		return telefono;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#setTelefono(java.lang.Integer)
	 */
	@Override
	public void setTelefono(Integer telefono) {
		this.telefono = telefono;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#getCorreo()
	 */
	@Override
	public String getCorreo() {
		return correo;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#setCorreo(java.lang.String)
	 */
	@Override
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#getFoto()
	 */
	@Override
	public FileInputStream getFoto() {
		return foto;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.PersonaInterface#setFoto(java.io.FileInputStream)
	 */
	@Override
	public void setFoto(FileInputStream foto) {
		this.foto = foto;
	}
	
	
}
