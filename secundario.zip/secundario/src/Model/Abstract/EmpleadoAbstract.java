package Model.Abstract;

import Model.Interface.EmpleadoInterface;

public abstract class EmpleadoAbstract extends PersonaAbstract implements EmpleadoInterface {

	private Integer legajo;
	private Boolean estado;
	
	/* (non-Javadoc)
	 * @see Model.Abstract.EmpleadoInterface#getLegajo()
	 */
	@Override
	public Integer getLegajo() {
		return legajo;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.EmpleadoInterface#setLegajo(java.lang.Integer)
	 */
	@Override
	public void setLegajo(Integer legajo) {
		this.legajo = legajo;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.EmpleadoInterface#getEstado()
	 */
	@Override
	public Boolean getEstado() {
		return estado;
	}
	/* (non-Javadoc)
	 * @see Model.Abstract.EmpleadoInterface#setEstado(java.lang.Boolean)
	 */
	@Override
	public void setEstado(Boolean estado) {
		this.estado = estado;
	}
	
	
}
