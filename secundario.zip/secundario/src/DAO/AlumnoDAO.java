package DAO;

import Model.Interface.AlumnoInterface;

public class AlumnoDAO {

	ConnectionSQL cc = new ConnectionSQL();
	
	public void insertarAlumno(AlumnoInterface al){
		
		cc.conectar();
		
		
		cc.ejecutar("INSERT INTO alumnos (DNI,DNITutor,legajoTutor,codCurso,matricula,establecimientoAnterior,estado,constanciaSexto,FechaEmision,nombreMadre,apellidoMadre,nombrePadre,apellidoPadre,observacion) "
					+ "VALUES ("+al.getDni()+",null,null,null,"+al.getMatricula()+",'"+al.getEstablecimientoAnterior()+"',"+al.getEstado()+",'"+al.getConstanciaSexto()+"','"+al.getFechaEmision()+"','"+al.getNombreMadre()+"','"+al.getApellidoMadre()+"','"+al.getNombrePadre()+"','"+al.getApellidoPadre()+"','"+al.getObservacion()+"')");

		
	}
}
