package DAO;

import Model.Interface.NacionalidadInterface;

public class NacionalidadDAO {
	
	ConnectionSQL cc = new ConnectionSQL();
	
	public void insertarNacionalidad(NacionalidadInterface n){
		
		cc.conectar();
		cc.ejecutar("INSERT INTO paises (codPais,pais,nacionalidad) "
				+ "VALUES (NULL,'"+n.getPais()+"','"+n.getNacionalidad()+"')");
	
		cc.ejecutar("INSERT INTO provincias (codProvincia,codPais,provincia) "
				+ "VALUES (NULL,"+n.getCodPais()+",'"+n.getProvincia()+"')");

		cc.ejecutar("INSERT INTO localidades (codLocalidad,codProvincia,localidad) "
				+ "VALUES (NULL,"+n.getCodProvincia()+",'"+n.getLocalidad()+"')");

	}

}
