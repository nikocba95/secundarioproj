package DAO;

import Model.Interface.DomicilioInterface;
import Model.Interface.NacionalidadInterface;

public class DomicilioDAO {
	
	ConnectionSQL cc = new ConnectionSQL();
	
	public void insertarDomicilio(DomicilioInterface d,NacionalidadInterface n){
		
		cc.conectar();
		cc.ejecutar("INSERT INTO domicilios (codDomicilio,codLocalidad,codProvincia,Barrio,calle,numero,piso,dpto) "
				+ "VALUES ("+d.getCodDomicilio()+","+n.getCodLocalidad()+","+n.getCodProvincia()+",'"+d.getBarrio()+"','"+d.getCalle()+"',"
						+ ""+d.getNumero()+","+d.getPiso()+",'"+d.getDpto()+"')");
		
	}

}
