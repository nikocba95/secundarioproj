package DAO;

import Model.Interface.AlumnoInterface;
import Model.Interface.DomicilioInterface;
import Model.Interface.NacionalidadInterface;

public class PersonaDAO {
	
	ConnectionSQL cc = new ConnectionSQL();
	
	public void insertarPersona(AlumnoInterface al,NacionalidadInterface n, DomicilioInterface d){
		
		cc.conectar();
		
		cc.ejecutar("INSERT INTO personas (DNI,nombre,apellido,sexo,fechaNac,codProvinciaNac,codDomicilio,telefono,correo,foto,cuil) "
				+ "VALUES ("+al.getDni()+",'"+al.getNombre()+"','"+al.getApellido()+"','"+al.getSexo()+"','"+al.getFechaNacimiento()+"',"
						+ ""+n.getCodProvincia()+","+d.getCodDomicilio()+","+al.getTelefono()+",'"+al.getCorreo()+"',"+al.getFoto()+","+al.getCuil()+")");
			
		cc.ejecutar("INSERT INTO nacionalidad (codPais,DNI) VALUES ("+n.getCodPais()+","+al.getDni()+")");
	}

}
